#!/bin/bash
# Build script for Vercel deployment
npm run build